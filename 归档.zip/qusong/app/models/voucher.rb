class Voucher < ApplicationRecord
  belongs_to :order
end
