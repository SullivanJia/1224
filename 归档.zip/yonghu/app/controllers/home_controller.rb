class HomeController < ApplicationController
  def user
  end
end
