require 'test_helper'

class UserAddressTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
