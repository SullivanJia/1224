class CitiesWorker < ApplicationRecord
  belongs_to :city
  belongs_to :worker
end
