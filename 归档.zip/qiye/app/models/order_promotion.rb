class OrderPromotion < ApplicationRecord
  belongs_to :coupon_list
end
