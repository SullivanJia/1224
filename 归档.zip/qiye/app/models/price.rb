class Price < ApplicationRecord
  belongs_to :product
end
