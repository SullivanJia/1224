class CouponList < ApplicationRecord
  has_one :order_promotion
end
