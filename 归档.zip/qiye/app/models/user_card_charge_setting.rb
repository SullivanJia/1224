class UserCardChargeSetting < ApplicationRecord
end
