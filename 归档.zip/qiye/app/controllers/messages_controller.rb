class MessagesController < ApplicationController
  # GET /categories
  # GET /categories.json
  def index
  end
end
